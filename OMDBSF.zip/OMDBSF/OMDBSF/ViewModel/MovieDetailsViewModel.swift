//
//  MovieDetailsViewModel.swift
//  OMDBSF
//
//  Created by Ravi Chandra Sekhar SARIKA on 17/08/21.
//

import Foundation
class MovieDetailsViewModel {
    var details: MovieDetails?
}
