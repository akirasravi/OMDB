//
//  MovieTableViewCell.swift
//  OMDBSF
//
//  Created by Ravi Chandra Sekhar SARIKA on 16/08/21.
//

import UIKit

protocol MovieTableViewCellDelegate: class {
    func favouriteclicked()
}

class MovieTableViewCell: UITableViewCell {
    @IBOutlet weak var moviePoster: UIImageView!
    @IBOutlet weak var title: UILabel!
    @IBOutlet weak var year: UILabel!
    @IBOutlet weak var abc: UILabel!
    @IBOutlet weak var faviourite: UIButton!
    weak var delegate: MovieTableViewCellDelegate?
    var movie: Search?
    var isFavourite: Bool = false
    var showFaviourite: Bool = false
    public static let reusableIdentifier: String = "common.movieTableViewCell.cell"

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    func configure(movie: Search, isFavourite: Bool, showFaviourite: Bool){
        self.movie = movie
        title.text = movie.title
        year.text = movie.year
        abc.text = movie.type
        self.isFavourite = isFavourite
        faviourite.setTitle("", for: .normal)
        moviePoster.imageFromServerURL(urlString:movie.poster , PlaceHolderImage: UIImage())
        if showFaviourite {
            let icon = isFavourite ? UIImage(systemName: "heart.fill") : UIImage(systemName: "heart")
            faviourite.setImage(icon, for: .normal)
        }
        
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    @IBAction func clickedFaviourite(_ sender: Any) {
        if movie != nil {
            if !isFavourite {
                CoreDataHelper.shared.saveMovieTolocalStorage(movie: movie!)
            }else {
                CoreDataHelper.shared.deleteIfEntityAttributeExist(movie: movie!)
            }
            delegate?.favouriteclicked()
        }
    }
}
