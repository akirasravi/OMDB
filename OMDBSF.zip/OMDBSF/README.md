Used MVVM architecture.
Used core data for peristance.
Use swift 5 with story boards.