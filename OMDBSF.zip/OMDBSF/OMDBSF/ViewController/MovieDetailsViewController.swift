//
//  MovieDetailsViewcontroller.swift
//  OMDBSF
//
//  Created by Ravi Chandra Sekhar SARIKA on 17/08/21.
//

import UIKit

class MovieDetailsViewController: UIViewController {
    
    @IBOutlet weak var movieTitle: UILabel!
    @IBOutlet weak var director: UILabel!
    @IBOutlet weak var Synopsys: UILabel!
    @IBOutlet weak var poster: UIImageView!
    @IBOutlet weak var year: UILabel!
    var viewModel: MovieDetailsViewModel = MovieDetailsViewModel()
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        title = "Movie Details"
        view.backgroundColor = UIColor.colorFromHex("#9E1C40")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        movieTitle.text =   "Ttile: " + (viewModel.details?.title ?? "")
        director.text = "Director: " +  (viewModel.details?.director ?? "")
        Synopsys.text = "Plot: \n\n" + (viewModel.details?.plot ?? "")
        year.text = "Year: " + (viewModel.details?.year ?? "")
        Synopsys.numberOfLines = 0
        poster.imageFromServerURL(urlString:viewModel.details?.poster ?? "" , PlaceHolderImage: UIImage())
    }
}
