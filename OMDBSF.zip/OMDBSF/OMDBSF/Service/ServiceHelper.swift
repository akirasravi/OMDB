//
//  ServiceHelper.swift
//  OMDBSF
//
//  Created by Ravi Chandra Sekhar SARIKA on 16/08/21.
//

import Foundation

protocol Services {
    func searchMovies(searchString: String, completion: @escaping (SearchResults?,Error?) -> Void)
    func getMovieDetails(movietitle: String, completion: @escaping (MovieDetails?,Error?) -> Void)

}

//read from json
class ServiceMock: Services{
    
    func searchMovies(searchString: String, completion: @escaping (SearchResults?,Error?) -> Void) {
        
        if let data = getDataFromDic(dic: readJSONFile("searchm")) {
            do {
                let model = try JSONDecoder().decode(SearchResults.self, from:data)
                print("My resp:")
                print(model)
                print("My respEnd:")
                completion(model, nil)
            } catch let err {
                print(err)
                completion(nil, err)
            }
        }
    }
    
    
    func getMovieDetails(movietitle: String, completion: @escaping (MovieDetails?,Error?) -> Void) {
        if let data = getDataFromDic(dic: readJSONFile("details")) {
            do {
                let model = try JSONDecoder().decode(MovieDetails.self, from:data)
                print("My resp:")
                print(model)
                print("My respEnd:")
                completion(model, nil)
            } catch let err {
                print(err)
                completion(nil, err)
            }
        }
    }
    
    public func getDataFromDic(dic: [String: Any]) -> Data? {
        return getDataFromJsonString(data: dic)
    }
    
    public func readJSONFile(_ file : String) -> Dictionary<String, AnyObject> {
        let mainBundle = Bundle.main
        var resultDict : Dictionary<String, AnyObject> = [:]
        if let path = mainBundle.path(forResource: file, ofType: "json") {
            do {
                let jsonData = try Data(contentsOf: URL(fileURLWithPath: path), options: NSData.ReadingOptions.mappedIfSafe)
                do {
                    resultDict = try (JSONSerialization.jsonObject(with: jsonData, options: JSONSerialization.ReadingOptions.mutableContainers) as? Dictionary<String, AnyObject> ?? [:])

                } catch _ {
                    print("Error - Not able to serialize JSON response")
                }
            } catch _ {
                print("Error - Not able to read contents of file")
            }
        }

        return resultDict
    }
   

    public func getDataFromJsonString(data: Any) -> Data? {
        do {
            return try JSONSerialization.data(withJSONObject: data,
                                              options: .prettyPrinted)
        } catch let error {
            print("Failed to convert to data \(error.localizedDescription)")
        }
        return nil
    }
    
}

class ServiceHelper: Services {
    var baseUrl = "http://www.omdbapi.com/?apikey=9a622f6c"
    init() {
        let configuration = URLSessionConfiguration.default
                configuration.httpCookieStorage = HTTPCookieStorage.shared
                configuration.requestCachePolicy = .reloadIgnoringLocalCacheData
                configuration.urlCache = nil
                var proxy = [AnyHashable: Any]()
                proxy[AnyHashable(kCFNetworkProxiesHTTPEnable)] = 0
                proxy[AnyHashable(kCFNetworkProxiesHTTPProxy)] = "bcproxy2.sgp.dbs.com"
                proxy[AnyHashable(kCFNetworkProxiesHTTPPort)] = 8080
                proxy[AnyHashable(kCFProxyUsernameKey)] = "srchsekhar"
                proxy[AnyHashable(kCFProxyPasswordKey)] = "JUN@Password"
                configuration.connectionProxyDictionary = proxy
    }
    
    func searchMovies(searchString: String, completion: @escaping (SearchResults?,Error?) -> Void) {
        let session = URLSession.shared
        let task = session.dataTask(with: URL(string: baseUrl+"&type=movie&s="+searchString)!, completionHandler: { data, response, error -> Void in
            
            print(response)
            guard let data = data else {
                completion(nil, error)
                return
            }
            do {
                let model = try JSONDecoder().decode(SearchResults.self, from:data)
                print("My resp:")
                print(model)
                print("My respEnd:")
                completion(model, nil)
            } catch let err {
                print(err)
                completion(nil, err)
            }
        })

        task.resume()
        
    }
    
    
    func getMovieDetails(movietitle: String, completion: @escaping (MovieDetails?,Error?) -> Void) {
        let session = URLSession.shared
        let task = session.dataTask(with: URL(string: baseUrl+"&type=movie&i="+movietitle)!, completionHandler: { data, response, error -> Void in
            
            guard let data = data else {
                completion(nil, error)
                return
            }
            do {
                let model = try JSONDecoder().decode(MovieDetails.self, from:data)
                print("My resp:")
                print(model)
                print("My respEnd:")
                completion(model, nil)
            } catch let err {
                print(err)
                completion(nil, err)
            }
        })

        task.resume()
        
    }
    
    
    
   
    
   
}
