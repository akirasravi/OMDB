//
//  CoreDataHelper.swift
//  OMDBSF
//
//  Created by Ravi Chandra Sekhar SARIKA on 16/08/21.
//

import Foundation
import CoreData
import UIKit
class CoreDataHelper {
    public static let shared = CoreDataHelper()
    func saveMovieTolocalStorage(movie: Search) {
      
      guard let appDelegate =
        UIApplication.shared.delegate as? AppDelegate else {
        return
      }
      
      // 1
      let managedContext =
        appDelegate.persistentContainer.viewContext
        
        deleteIfEntityAttributeExist(movie: movie)
      
      // 2
      let entity =
        NSEntityDescription.entity(forEntityName: "Movies",
                                   in: managedContext)!

      
      let movieEntity = NSManagedObject(entity: entity,
                                   insertInto: managedContext)
      
        
      // 3
        movieEntity.setValue(movie.title, forKey: "title")
        movieEntity.setValue(movie.year, forKey: "year")
        movieEntity.setValue(movie.type, forKey: "type")
        movieEntity.setValue(movie.poster, forKey: "poster")

      
      // 4
      do {
        try managedContext.save()
      } catch let error as NSError {
        print("Could not save. \(error), \(error.userInfo)")
      }
    }
    
    func deleteIfEntityAttributeExist(movie: Search) {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let managedContext = appDelegate.persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Movies")
        fetchRequest.predicate = NSPredicate(format: "title == %@", (movie.title ?? ""))
        
        do {
            if let res = try managedContext.fetch(fetchRequest) as? [NSManagedObject] {
                for r in res {
                    managedContext.delete(r)
                }
            }
        } catch let error as NSError {
          print("Could not fetch. \(error), \(error.userInfo)")
        }
    }
    
    func getMoviesfromStorage() -> [Search]{
        //1
        guard let appDelegate =
          UIApplication.shared.delegate as? AppDelegate else {
            return []
        }
        
        let managedContext =
          appDelegate.persistentContainer.viewContext
        
        //2
        let fetchRequest =
          NSFetchRequest<NSManagedObject>(entityName: "Movies")
        
        //3
        do {
          let movies =  try managedContext.fetch(fetchRequest)
           return  convertToMoviesObject(result: movies)
        } catch let error as NSError {
          print("Could not fetch. \(error), \(error.userInfo)")
        }
        return []
    }
    
    func convertToMoviesObject(result: [NSManagedObject]) -> [Search] {
        var movies: [Search] = []
        
        for item in result {
            movies.append(Search(title: item.value(forKeyPath: "title") as? String ?? "",
                                year:  item.value(forKeyPath: "year") as? String ?? "", imdbID: "",
                                            type: item.value(forKeyPath: "type") as? String ?? "", poster: item.value(forKeyPath: "poster") as? String ?? ""))
        }
        return movies
    }
}
