//
//  MovieSearchViewModel.swift
//  OMDBSF
//
//  Created by Ravi Chandra Sekhar SARIKA on 16/08/21.
//

import Foundation

class MovieSearchViewModel {
    var serachResults: [Search] = []
    var favourites: [Search] = CoreDataHelper.shared.getMoviesfromStorage()
    var tabledata: [Search] = []
    weak var delegate: MovieSearchViewControllerDelegate?
    var details: MovieDetails?
    var services: Services = ServiceHelper()  //change this to ServicesHelper to hit actual services
    func serachMovies(search: String) {
        services.searchMovies(searchString: search) { [unowned self] (response, error) in
            if let response = response {
                if response.error != nil {
                    self.delegate?.showAlert(title: "alert", message: response.error!)
                    return
                }
                if let movies = response.search {
                    self.serachResults = movies
                    self.tabledata = movies
                }
                self.delegate?.reloadTable()
            }else {
                self.delegate?.showAlert(title: "alert", message: "failed search")
            }
        }
        
    }
    
    func getMovieDetails(title: String) {
        services.getMovieDetails(movietitle: title) { [unowned self] (response, error) in
            if let response = response {
                if response.error != nil {
                    self.delegate?.showAlert(title: "alert", message: response.error!)
                    return
                }
                details = response
                self.delegate?.gotoDetails()
            }else {
                self.delegate?.showAlert(title: "alert", message: "failed details")
            }
        }
        
    }
        
    func switchToSearch() {
        self.tabledata = serachResults
        self.delegate?.reloadTable()
    }
    
    func relodFaviouritesfromStore() {
        favourites = CoreDataHelper.shared.getMoviesfromStorage()
    }
    
    func switchToFavourites() {
        favourites = CoreDataHelper.shared.getMoviesfromStorage()
        self.tabledata = favourites
        self.delegate?.reloadFavourites()
    }
    
    func isFavoutite(movie: Search) -> Bool {
        let x = favourites.filter{ $0.title == movie.title}
        return x.count > 0
    }
}
