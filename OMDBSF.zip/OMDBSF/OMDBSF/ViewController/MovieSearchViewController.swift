//
//  MovieSearchViewController.swift
//  OMDBSF
//
//  Created by Ravi Chandra Sekhar SARIKA on 16/08/21.
//
import UIKit

protocol MovieSearchViewControllerDelegate: class {
    func reloadTable()
    func reloadFavourites()
    func gotoDetails()
    func showAlert(title:String, message: String)
}

class MovieSearchViewController: UIViewController {
    @IBOutlet var tableView: UITableView!
    @IBOutlet weak var favouritesTableView: UITableView!
    @IBOutlet weak var tabBar: UITabBar!
    @IBOutlet weak var searchBar: UISearchBar!
    var viewModel = MovieSearchViewModel()
    var tabBarItems =  [
        UITabBarItem(tabBarSystemItem: .search, tag: 0),
        UITabBarItem(tabBarSystemItem: .favorites, tag : 1)
        ]
    var selected: String?
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.title = "OMDB"
        self.navigationController?.navigationBar.tintColor = UIColor.colorFromHex("#9E1C40")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        viewModel.delegate = self
        
        //tabBar setup
        tabBar.barStyle = .default
        tabBar.itemSpacing = .leastNonzeroMagnitude
        tabBar.backgroundColor = UIColor.colorFromHex("#9E1C40")
        tabBar.tintColor = .white
        tabBar.barTintColor = UIColor.colorFromHex("#9E1C40")
        tabBar.delegate = self
        tabBar.items = tabBarItems
        tabBar.selectedItem = tabBarItems[0]
        favouritesTableView.delegate = self
        favouritesTableView.dataSource = self
        favouritesTableView.register(UINib(nibName: "MovieTableViewCell", bundle: nil), forCellReuseIdentifier: MovieTableViewCell.reusableIdentifier)
        favouritesTableView.separatorStyle = .singleLine
        favouritesTableView.tintColor = UIColor.white
        favouritesTableView.backgroundColor = UIColor.colorFromHex("#9E1C40")
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(UINib(nibName: "MovieTableViewCell", bundle: nil), forCellReuseIdentifier: MovieTableViewCell.reusableIdentifier)
        
        // Change the Tint Color
        self.searchBar.barTintColor = UIColor.colorFromHex("#BC214B")
        self.searchBar.tintColor = UIColor.white
        // Show/Hide Cancel Button
        self.searchBar.showsCancelButton = true
        // Change TextField Colors
        let searchTextField = self.searchBar.searchTextField
        searchTextField.textColor = UIColor.white
        searchTextField.clearButtonMode = .never
        searchTextField.backgroundColor = UIColor.colorFromHex("#9E1C40")
        // Change Glass Icon Color
        let glassIconView = searchTextField.leftView as! UIImageView
        glassIconView.image = glassIconView.image?.withRenderingMode(.alwaysTemplate)
        glassIconView.tintColor = UIColor.colorFromHex("#BC214B")
        
        
        self.searchBar.keyboardAppearance = .dark
        
        self.tableView.separatorStyle = .singleLine
        self.tableView.tintColor = UIColor.white
        self.tableView.backgroundColor = UIColor.colorFromHex("#9E1C40")
        searchBar.isHidden = false
        tableView.isHidden = false
        favouritesTableView.isHidden = true
        tableView.tableFooterView = UIView()
        favouritesTableView.tableFooterView = UIView()
        searchBar.delegate = self


    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "detailsviewcontrollerseg" {
            let detailsVC = segue.destination as! MovieDetailsViewController
            detailsVC.viewModel.details = viewModel.details
           // DestViewController.selectedCountry = selected
        }
    }
}

extension MovieSearchViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.tabledata.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100.0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell( withIdentifier: MovieTableViewCell.reusableIdentifier, for: indexPath) as? MovieTableViewCell else {
            return UITableViewCell()
        }
        
        cell.configure(movie: viewModel.tabledata[indexPath.row], isFavourite: viewModel.isFavoutite(movie: viewModel.tabledata[indexPath.row]), showFaviourite: true)
        cell.backgroundColor = UIColor.clear
        let myCustomSelectionColorView = UIView()
        myCustomSelectionColorView.backgroundColor = UIColor.colorFromHex("#BC214B")
        cell.selectedBackgroundView = myCustomSelectionColorView
        cell.delegate = self
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let selectedMovie = viewModel.tabledata[indexPath.row]
        viewModel.getMovieDetails(title: selectedMovie.imdbID ?? "")
        self.searchBar.searchTextField.endEditing(true)
    }
}

extension MovieSearchViewController: UISearchBarDelegate {
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if searchText.count > 2 {
            viewModel.serachMovies(search: searchText)
        }
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        searchBar.text = ""
        DispatchQueue.main.async { [weak self] in
            self?.tableView.reloadData()
        }
    }
}


extension MovieSearchViewController: MovieSearchViewControllerDelegate {
    func reloadTable() {
        DispatchQueue.main.async { [weak self] in
            self?.tableView.reloadData()
        }
    }
    func reloadFavourites() {
        DispatchQueue.main.async { [weak self] in
            self?.favouritesTableView.reloadData()
        }
    }
    func gotoDetails() {
        DispatchQueue.main.async { [weak self] in
            self?.performSegue(withIdentifier: "detailsviewcontrollerseg", sender: self)
        }
    }
    
    func showAlert(title: String, message: String) {
        let  alertController = UIAlertController.init(title: title,
                                                      message: message, preferredStyle: .alert)
        
        let action = UIAlertAction.init(title: "No", style: .default) { (_) in
            
            DispatchQueue.main.async(execute: { [weak self] in
                self?.dismiss(animated: true, completion: nil)
            })
            
        }
        
        alertController.addAction(action)
        DispatchQueue.main.async { [weak self] in
            self?.present(alertController, animated: true, completion: nil)
        }
    }
}

extension MovieSearchViewController: UITabBarDelegate {
    func tabBar(_ tabBar: UITabBar, didSelect item: UITabBarItem) {
        if item.tag == 1 {
            searchBar.isHidden = true
            tableView.isHidden = true
            favouritesTableView.isHidden = false
            viewModel.switchToFavourites()
        }else {
            searchBar.isHidden = false
            tableView.isHidden = false
            favouritesTableView.isHidden = true
            viewModel.switchToSearch()
        }
        
    }
}


extension MovieSearchViewController: MovieTableViewCellDelegate {
    func favouriteclicked() {
        viewModel.relodFaviouritesfromStore()
        reloadTable()
        reloadFavourites()
    }
}
